# CP02 v1.1 — Motivo central

- Rayo original conservado hasta 28 %, con relevo gradual 28–46 %.
- Curvatura e irregularidad conservadas en el tramo medio; enderezamiento 62–90 %.
- Cuerpo de aproximadamente 4.08 px fuente al 50 % y 5.18 px al 75 %, más núcleo y halo local.
- Eje original toma el relevo 82–90 %. Sin cambios de cámara, fondo, estrellas, controles o movimiento reducido.

No se declara aprobado el ajuste. Las pruebas finales comprueban curva a 50 y 75 %, convergencia al 90 %, reversibilidad y ausencia de errores de consola/carga.

El informe con vídeo y capturas se entrega en el repositorio, no dentro de este ZIP ligero:
https://github.com/LarryCapija1990/pruebapiloto/blob/main/piloto02-f4/revision-cp02/INFORME_CP02.md
