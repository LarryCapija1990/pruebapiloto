# Piloto 02 — F4 CP02 v1.1

Corrección puntual del motivo central de Thunder and Lightning → Innervision. Pendiente de revisión visual. Sin cambios de cámara, fondo ni estrellas; sin otros álbumes ni cambios en Nero’s Vice.

1. Extrae este ZIP por completo.
2. Abre su carpeta en VS Code y una terminal.
3. Windows: py prototipo/server.py
   macOS / Linux: python3 prototipo/server.py
4. Abre http://127.0.0.1:4173 en Chrome o Edge y mantén la terminal abierta.

Requiere Python 3.10+ y JavaScript/WebGL. No instala paquetes. No abrir index.html mediante file:// ni desde el ZIP. Si el puerto está ocupado: py prototipo/server.py --port 4174. La cabecera debe mostrar F4 / CP02; si muestra CP01, estás abriendo la versión anterior.

Rayo original hasta el 28 %, curva e irregularidad en el tramo medio, enderezamiento progresivo entre 62 y 90 %. Cuerpo y luz reforzados, sin pulsaciones temporales. Scroll, control de recorrido, teclado y modo reducido siguen disponibles.

Informe y comparativa en GitHub:
https://github.com/LarryCapija1990/pruebapiloto/blob/main/piloto02-f4/revision-cp02/INFORME_CP02.md

El ZIP acumulativo del tag incluye fuentes, pruebas, vídeo y capturas:
https://github.com/LarryCapija1990/pruebapiloto/archive/refs/tags/piloto02-f4-cp02-v1.1.zip
